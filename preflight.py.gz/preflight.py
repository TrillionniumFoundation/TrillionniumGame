"""Fixed-source preflight. Stores blobs only after tests; never mutates refs."""
from __future__ import annotations
import ast
import base64
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import urllib.request

REPO = "TrillionniumFoundation/TrillionniumGame"
BASE = "3fb74322d014a6d7ddc050529145583b60c7ae2d"
BASE_TREE = "546e604e147fea3b477a2fef5a27286ece78bca8"
ORIGINALS = {
    "scripts/check-trnm-server.py": "087837a6f153e04303c0c9094ce03c577a2dc845",
    "scripts/check-rust-foundation.py": "c5f9471b58e656060aaab29eac70ee5209b82a75",
    "docs/TESTING_AND_EVIDENCE.md": "7be8f029b39c50436e4b8af615bbad662648bc82",
    "docs/status/TRNM_SERVER_STATUS.json": "61bac031c96dd16b33e0bbd0985b2a32e3424814",
}
TEST_PATH = "tests/control_plane/test_trnm_server_dependency_contract.py"
RECORDS = []


def git(*args):
    return subprocess.check_output(["git", *args], timeout=30).decode().strip()


def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def run(args, expected=0):
    result = subprocess.run(args, capture_output=True, text=True, timeout=240)
    output = result.stdout + result.stderr
    count = re.search(r"Ran (\d+) tests", output)
    row = {"command": args, "exit_code": result.returncode,
           "tests": int(count.group(1)) if count else None,
           "output_sha256": hashlib.sha256(output.encode()).hexdigest()}
    RECORDS.append(row)
    print("CHECK=" + json.dumps(row), flush=True)
    if result.returncode != expected:
        print(output[-16000:], flush=True)
        raise RuntimeError("preflight command failed")
    return output


def apply(root: Path):
    path = root / "scripts/check-trnm-server.py"
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source)
    main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "main")
    start_node = next(n for n in main.body if isinstance(n, ast.Assign)
                      and any(isinstance(t, ast.Name) and t.id == "expected_dependencies" for t in n.targets))
    build_node = next(n for n in main.body if isinstance(n, ast.Assign)
                      and any(isinstance(t, ast.Name) and t.id == "expected_build_dependencies" for t in n.targets))
    end_node = main.body[main.body.index(build_node) + 1]
    if not isinstance(start_node.value, ast.Dict) or not isinstance(end_node, ast.If):
        raise RuntimeError("unexpected dependency contract structure")
    lines = source.splitlines(keepends=True)
    block = "".join(lines[start_node.lineno - 1:end_node.end_lineno])
    assignment = "".join(lines[start_node.lineno - 1:start_node.end_lineno])
    new_block = block.replace(assignment, "    expected_dependencies = expected_persistence_dependencies()\n", 1)
    function = "def validate_dependency_boundary(manifest: dict[str, object]) -> None:\n" + new_block + "\n\n"
    edited = source.replace(block, "    validate_dependency_boundary(manifest)\n", 1)
    edited = edited.replace("import json\n", "import importlib.util\nimport json\nfrom copy import deepcopy\n", 1)
    edited = edited.replace("def main() -> int:\n", LOADER + function + "def main() -> int:\n", 1)
    ast.parse(edited)
    path.write_text(edited, encoding="utf-8")
    test = root / TEST_PATH
    if test.exists():
        raise RuntimeError("refuse to overwrite a new test path")
    test.write_text(TEST_SOURCE, encoding="utf-8")
    doc = root / "docs/TESTING_AND_EVIDENCE.md"
    value = doc.read_text(encoding="utf-8")
    if "## 16. Shared persistence dependency policy" in value:
        raise RuntimeError("documentation section already exists")
    doc.write_text(value.rstrip() + "\n\n" + DOCUMENTATION, encoding="utf-8")
    status_path = root / "docs/status/TRNM_SERVER_STATUS.json"
    status = json.loads(status_path.read_text(encoding="utf-8"))
    status["dependency_contract_source_candidate"] = {
        "policy_source": "scripts/check-rust-foundation.py::EXPECTED_DEPENDENCIES",
        "consumer": "scripts/check-trnm-server.py",
        "regression_suite": TEST_PATH,
        "scope": "One exact persistence dependency table; unchanged protobuf build pins and server invariants.",
        "accepted": False,
        "gap_closed": False,
        "runtime_behavior_changed": False,
    }
    status_path.write_text(json.dumps(status, indent=2) + "\n", encoding="utf-8")


def main():
    root = Path.cwd()
    if git("rev-parse", "HEAD") != BASE or git("rev-parse", "HEAD^{tree}") != BASE_TREE:
        raise RuntimeError("wrong fixed source identity")
    if git("status", "--porcelain"):
        raise RuntimeError("dirty fixed source checkout")
    for path, sha in ORIGINALS.items():
        if blob((root / path).read_bytes()) != sha or git("rev-parse", "HEAD:" + path) != sha:
            raise RuntimeError("original blob mismatch: " + path)
    before = run([sys.executable, "scripts/check-trnm-server.py"], expected=1)
    if "server candidate changed the reviewed persistence dependency boundary" not in before:
        raise RuntimeError("baseline did not reproduce the recorded defect")
    print("BASELINE_REPRODUCED=second dependency allowlist rejects the exact current manifest", flush=True)
    apply(root)
    paths = ["scripts/check-trnm-server.py", TEST_PATH,
             "docs/TESTING_AND_EVIDENCE.md", "docs/status/TRNM_SERVER_STATUS.json"]
    # Staging binds normal tracked-file checks but does not create a commit.
    subprocess.run(["git", "add", "--", *paths], check=True, timeout=30)
    changed = set(git("diff", "--cached", "--name-only").splitlines())
    if changed != set(paths):
        raise RuntimeError("unexpected staged change set")
    run([sys.executable, "-m", "compileall", "-q", "scripts", "tools", "tests"])
    run([sys.executable, "scripts/check-trnm-server.py"])
    run([sys.executable, "scripts/check-rust-foundation.py"])
    tests = run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py", "-v"])
    if not re.search(r"Ran 401 tests\b", tests) or not re.search(r"\nOK\s*$", tests):
        raise RuntimeError("full corpus was not exactly 401 passing tests")
    for name in ("check-documentation-authority.py", "check-plan.py", "check-evidence-index.py",
                 "check-gap-register.py", "derive-gap-status.py", "derive-gates.py",
                 "check-status-transitions.py", "check-workflow-action-policy.py", "check-repository-hygiene.py"):
        run([sys.executable, "scripts/" + name])
    patch_bytes = subprocess.check_output(["git", "diff", "--cached", "--binary", "--full-index"], timeout=30)
    if len(patch_bytes) > 128 * 1024:
        raise RuntimeError("unexpected patch size")
    entries = []
    for path in paths:
        data = (root / path).read_bytes()
        mode, kind, sha = git("ls-files", "--stage", path).split()[:3]
        # ls-files fields are mode, blob, stage rather than ls-tree fields.
        expected_sha = kind
        if expected_sha != blob(data):
            raise RuntimeError("staged blob differs from tested bytes")
        request = urllib.request.Request(
            "https://api.github.com/repos/" + REPO + "/git/blobs",
            data=json.dumps({"content": base64.b64encode(data).decode(), "encoding": "base64"}).encode(),
            headers={"Authorization": "Bearer " + os.environ["GITHUB_TOKEN"],
                     "Accept": "application/vnd.github+json", "Content-Type": "application/json",
                     "User-Agent": "trnm-fixed-source-preflight"}, method="POST")
        with urllib.request.urlopen(request, timeout=30) as response:
            record = json.load(response)
        if record.get("sha") != expected_sha:
            raise RuntimeError("stored blob mismatch")
        entries.append({"path": path, "mode": mode, "type": "blob", "sha": expected_sha})
    print("PREFLIGHT_RECEIPT=" + json.dumps({"source": BASE, "base_tree": BASE_TREE,
          "tested_tree": git("write-tree"), "entries": entries, "checks": RECORDS,
          "ref_mutated": False, "review_submitted": False, "accepted": False}), flush=True)
    print("PATCH_GZIP_BASE64=" + base64.b64encode(gzip.compress(patch_bytes, mtime=0)).decode(), flush=True)


LOADER = 'def expected_persistence_dependencies() -> dict[str, object]:\n    """Read the same closed dependency policy used by the foundation checker.\n\n    Resolve only the sibling script, never a module selected by cwd or sys.path.\n    Importing that script does not execute its command-line validation. No local\n    duplicate or fallback policy may silently diverge from the foundation table.\n    """\n    path = Path(__file__).with_name("check-rust-foundation.py")\n    spec = importlib.util.spec_from_file_location("trnm_server_foundation_policy", path)\n    if spec is None or spec.loader is None:\n        fail("foundation dependency policy loader is unavailable")\n    foundation = importlib.util.module_from_spec(spec)\n    try:\n        spec.loader.exec_module(foundation)\n        dependencies = foundation.EXPECTED_DEPENDENCIES["crates/trnm-persistence-pg"]\n    except (OSError, SyntaxError, AttributeError, KeyError, TypeError) as error:\n        fail("foundation dependency policy could not be loaded: " + type(error).__name__)\n    if not isinstance(dependencies, dict) or not dependencies:\n        fail("foundation persistence dependency policy must be a nonempty mapping")\n    return deepcopy(dependencies)\n\n\n'
TEST_SOURCE = '"""Real server-checker coverage; passing source checks is not runtime acceptance."""\nfrom __future__ import annotations\n\nimport ast\nfrom contextlib import redirect_stdout\nfrom copy import deepcopy\nimport importlib.util\nimport io\nimport json\nfrom pathlib import Path\nimport subprocess\nimport sys\nfrom tempfile import TemporaryDirectory\nimport tomllib\nimport unittest\nfrom unittest.mock import patch\n\nROOT = Path(__file__).resolve().parents[2]\nCHECKER = ROOT / "scripts/check-trnm-server.py"\nFOUNDATION = ROOT / "scripts/check-rust-foundation.py"\nMANIFEST = ROOT / "crates/trnm-persistence-pg/Cargo.toml"\n\n\ndef load(path: Path, name: str):\n    spec = importlib.util.spec_from_file_location(name, path)\n    if spec is None or spec.loader is None:\n        raise RuntimeError("test checker loader is unavailable")\n    module = importlib.util.module_from_spec(spec)\n    spec.loader.exec_module(module)\n    return module\n\n\nclass ServerDependencyContractTests(unittest.TestCase):\n    @classmethod\n    def setUpClass(cls):\n        cls.server = load(CHECKER, "trnm_server_dependency_test")\n        cls.foundation = load(FOUNDATION, "trnm_foundation_dependency_test")\n        cls.manifest = tomllib.loads(MANIFEST.read_text(encoding="utf-8"))\n\n    def reject(self, section, mutate):\n        self.server.validate_dependency_boundary(deepcopy(self.manifest))\n        changed = deepcopy(self.manifest)\n        mutate(changed[section])\n        self.assertNotEqual(changed, self.manifest, "hostile fixture must change its target")\n        with self.assertRaisesRegex(SystemExit, "dependency boundary"):\n            self.server.validate_dependency_boundary(changed)\n\n    def test_actual_manifest_passes_shared_boundary(self):\n        self.server.validate_dependency_boundary(deepcopy(self.manifest))\n\n    def test_server_and_foundation_use_identical_exact_table(self):\n        actual = self.server.expected_persistence_dependencies()\n        self.assertEqual(actual, self.foundation.EXPECTED_DEPENDENCIES["crates/trnm-persistence-pg"])\n        self.assertEqual(actual["openssl"], "=0.10.81")\n        self.assertEqual(actual, self.manifest["dependencies"])\n\n    def test_policy_is_a_deep_copy(self):\n        first = self.server.expected_persistence_dependencies()\n        first["tokio"]["features"].append("full")\n        first.pop("openssl")\n        self.assertEqual(self.server.expected_persistence_dependencies(), self.manifest["dependencies"])\n\n    def test_missing_openssl_rejects(self):\n        self.reject("dependencies", lambda d: d.pop("openssl"))\n\n    def test_unknown_dependency_rejects(self):\n        self.reject("dependencies", lambda d: d.update({"unknown": "=1.0.0"}))\n\n    def test_version_ranges_and_wrong_pin_reject(self):\n        for value in ("0.10.81", "^0.10.81", "*", "=0.10.80"):\n            with self.subTest(value=value):\n                self.reject("dependencies", lambda d: d.update(openssl=value))\n\n    def test_alternate_sources_and_dependency_alias_reject(self):\n        values = ({"git": "https://example.invalid/openssl"}, {"path": "../openssl"},\n                  {"version": "=0.10.81", "registry": "other"},\n                  {"version": "=0.10.81", "package": "other"})\n        for value in values:\n            with self.subTest(value=value):\n                self.reject("dependencies", lambda d: d.update(openssl=value))\n\n    def test_dependency_features_or_optional_mode_reject(self):\n        for value in ({"version": "=0.10.81", "features": ["vendored"]},\n                      {"version": "=0.10.81", "optional": True},\n                      {"version": "=0.10.81", "default-features": False}):\n            with self.subTest(value=value):\n                self.reject("dependencies", lambda d: d.update(openssl=value))\n\n    def test_other_runtime_pins_remain_exact(self):\n        self.reject("dependencies", lambda d: d.update(postgres="0.19"))\n\n    def test_runtime_features_remain_exact(self):\n        self.reject("dependencies", lambda d: d["tokio"]["features"].append("full"))\n\n    def test_internal_dependency_paths_remain_exact(self):\n        self.reject("dependencies", lambda d: d.update({"trnm-contracts": {"path": "../../foreign"}}))\n\n    def test_build_dependencies_remain_closed(self):\n        for mutate in (lambda d: d.pop("prost-build"),\n                       lambda d: d.update({"unknown-build": "=1.0.0"}),\n                       lambda d: d.update({"prost-build": "0.14"})):\n            with self.subTest(mutate=mutate):\n                self.reject("build-dependencies", mutate)\n\n    def test_missing_dependency_sections_reject(self):\n        for section in ("dependencies", "build-dependencies"):\n            with self.subTest(section=section):\n                data = deepcopy(self.manifest)\n                del data[section]\n                with self.assertRaisesRegex(SystemExit, "dependency boundary"):\n                    self.server.validate_dependency_boundary(data)\n\n    def test_missing_sibling_policy_has_no_fallback(self):\n        with TemporaryDirectory() as directory:\n            with patch.object(self.server, "__file__", str(Path(directory) / "check-trnm-server.py")):\n                with self.assertRaisesRegex(SystemExit, "policy could not be loaded"):\n                    self.server.expected_persistence_dependencies()\n\n    def test_malformed_or_empty_sibling_policy_has_no_fallback(self):\n        sources = ("", "EXPECTED_DEPENDENCIES = {}", "EXPECTED_DEPENDENCIES = []",\n                   "EXPECTED_DEPENDENCIES = {\'crates/trnm-persistence-pg\': {}}",\n                   "EXPECTED_DEPENDENCIES = {\'crates/trnm-persistence-pg\': []}", "syntax = (")\n        for source in sources:\n            with self.subTest(source=source), TemporaryDirectory() as directory:\n                path = Path(directory)\n                (path / "check-rust-foundation.py").write_text(source, encoding="utf-8")\n                with patch.object(self.server, "__file__", str(path / "check-trnm-server.py")):\n                    with self.assertRaisesRegex(SystemExit, "dependency policy"):\n                        self.server.expected_persistence_dependencies()\n\n    def test_cwd_cannot_shadow_sibling_policy(self):\n        with TemporaryDirectory() as directory:\n            fake = Path(directory) / "check-rust-foundation.py"\n            fake.write_text("raise RuntimeError(\'cwd shadow executed\')", encoding="utf-8")\n            result = subprocess.run([sys.executable, str(CHECKER)], cwd=directory,\n                                    capture_output=True, text=True, timeout=30)\n            self.assertEqual(result.returncode, 0, result.stderr)\n            self.assertEqual(json.loads(result.stdout)["status"], "trnm-server-source-contract-passed")\n\n    def test_main_calls_shared_boundary_without_a_duplicate_literal(self):\n        tree = ast.parse(CHECKER.read_text(encoding="utf-8"))\n        main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "main")\n        calls = [n for n in ast.walk(main) if isinstance(n, ast.Call)\n                 and isinstance(n.func, ast.Name) and n.func.id == "validate_dependency_boundary"]\n        self.assertEqual(len(calls), 1)\n        boundary = next(n for n in tree.body if isinstance(n, ast.FunctionDef)\n                        and n.name == "validate_dependency_boundary")\n        assignments = [n for n in ast.walk(boundary) if isinstance(n, ast.Assign)\n                       and any(isinstance(t, ast.Name) and t.id == "expected_dependencies" for t in n.targets)]\n        self.assertEqual(len(assignments), 1)\n        self.assertIsInstance(assignments[0].value, ast.Call)\n        self.assertEqual(assignments[0].value.func.id, "expected_persistence_dependencies")\n\n    def test_real_main_rejects_hostile_dependency_manifest(self):\n        changed = deepcopy(self.manifest)\n        changed["dependencies"]["unknown"] = "=1.0.0"\n        with patch.object(self.server.tomllib, "loads", return_value=changed):\n            with self.assertRaisesRegex(SystemExit, "reviewed persistence dependency boundary"):\n                self.server.main()\n\n    def test_real_main_still_rejects_missing_required_source(self):\n        missing = ROOT / "crates/trnm-persistence-pg/src/absent-contract-fixture.rs"\n        self.assertFalse(missing.exists())\n        with patch.object(self.server, "REQUIRED_FILES", self.server.REQUIRED_FILES | {missing}):\n            with self.assertRaisesRegex(SystemExit, "missing files"):\n                self.server.main()\n\n    def test_real_main_still_rejects_omitted_workflow_invocation(self):\n        original = Path.read_text\n        workflow = ROOT / ".github/workflows/trillionnium-game-merge-gate.yml"\n        def replaced(path, *args, **kwargs):\n            text = original(path, *args, **kwargs)\n            if path == workflow:\n                text = text.replace("python3 scripts/check-trnm-server.py", "echo omitted-server-check")\n            return text\n        with patch.object(Path, "read_text", replaced):\n            with self.assertRaisesRegex(SystemExit, "does not execute the server source contract"):\n                self.server.main()\n\n    def test_complete_real_server_checker_is_nonempty_and_noncreditable(self):\n        result = subprocess.run([sys.executable, str(CHECKER)], cwd=ROOT,\n                                capture_output=True, text=True, timeout=30)\n        self.assertEqual(result.returncode, 0, result.stderr)\n        report = json.loads(result.stdout)\n        self.assertEqual(report["status"], "trnm-server-source-contract-passed")\n        self.assertGreater(report["source_files"], 20)\n        self.assertGreaterEqual(report["source_tests"], 72)\n        for field in ("cargo_executed_here", "live_database_executed_here", "compatibility_credit", "sg4_complete"):\n            self.assertIs(report[field], False)\n\n\nif __name__ == "__main__":\n    unittest.main()\n'
DOCUMENTATION = "## 16. Shared persistence dependency policy\n\nThe canonical server checker reads `EXPECTED_DEPENDENCIES` from the sibling\n`scripts/check-rust-foundation.py`; it no longer carries a second persistence\ndependency table. The sibling is resolved from the checker file rather than the\nworking directory or import search path. Missing or malformed policy fails\nwithout a fallback, and callers receive a deep copy. The existing exact runtime\npins, internal paths and feature lists remain enforced, including the diagnostic\nOpenSSL pin. The server's protobuf build-dependency table remains unchanged.\n\n`tests/control_plane/test_trnm_server_dependency_contract.py` exercises the real\n`check-trnm-server.py` executable in complete test discovery, in addition to the\nother foundation/slice checkers. It also rejects missing/extra dependencies,\nranges, alternate sources, feature changes, unavailable policy, omitted required\nsource and removed aggregate invocation. These regressions ensure an unrelated\nslice checker cannot stand in for the canonical server source contract.\n\n```bash\npython3 scripts/check-trnm-server.py\npython3 scripts/check-rust-foundation.py\npython3 -m unittest discover -s tests -p 'test_*.py' -v\n```\n\nThis source-contract repair changes no Cargo manifest, lockfile, Rust runtime,\nDDL, workflow definition, deadline, required-job set or acceptance condition.\nIt does not establish database behavior, independent cryptographic review or\nproduction readiness. Exact-candidate execution and independent acceptance\nremain required for every applicable gap.\n"

if __name__ == "__main__":
    main()
