#!/usr/bin/env python3
"""Apply a fixed, hash-bound source repair; test before storing Git blobs only.

This diagnostic tool never updates refs, reviews, branch policy or release state.
It is kept on a tooling branch and is not a product-candidate file.
"""
from __future__ import annotations
import ast
import base64
import hashlib
import gzip
import importlib.util
import json
import os
import re
import subprocess
import sys
import urllib.request
from pathlib import Path

REPO = "TrillionniumFoundation/TrillionniumGame"
SOURCE = "421b33ca10e92ba393d93d8b27b70cc5f84f6f4e"
TREE = "3ca91b2f8809540206eeaf0a1aa4781b1bcf49d0"
EXPECTED = {
    "scripts/check-evidence-index.py": "888afcadc194280277d6b5ab5a615634b46eb776",
    "scripts/derive-gap-status.py": "f1c374e956d99ac5d8f9d6bd1505862de2b64816",
    "scripts/derive-gates.py": "ff008f3a046e781cbe6d4584cd7b9565b560ff2e",
    "scripts/check-gap-register.py": "fb916bbe71e941958dace8cd87aba88dbe501a84",
    "scripts/check-status-transitions.py": "b2e3026e61a8394d9fd0575e615dc175e4d36064",
    "docs/TESTING_AND_EVIDENCE.md": "6e525e6384c2d4855e0bc35c33686ea991f928d2",
    "docs/DOCUMENTATION_AUTHORITY.json": "e2eeb95d382b20da5849448c5dbaecbdb3038481",
    "docs/status/CURRENT_STATE.json": "03df0a495abc9a1db671dd91df168d52f0d0ab8c",
    "docs/evidence/index.json": "2431beaacf250ab668af4ad3b0df88f69ada62f9",
    "docs/status/GAP_REGISTER.json": "4ef3731538be8782eca3b064e441b65a053c3090",
    "docs/roadmap/NEXT_MILESTONE.json": "5176a0c18fd0a6bcdca6dd40f75e59cc1af45e3a",
    "docs/status/IMPLEMENTATION_INVENTORY.json": "cac0dd5bab67ecf71681148ff2586cd8cca58ad1",
}


def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def require(value, message):
    if not value:
        raise RuntimeError(message)


def replace_once(text, before, after):
    require(text.count(before) == 1, "source replacement is not unique: " + before[:100])
    return text.replace(before, after, 1)


def replace_function(text, name, replacement):
    found = [node for node in ast.parse(text).body if isinstance(node, ast.FunctionDef) and node.name == name]
    require(len(found) == 1, "function identity drift: " + name)
    node = found[0]
    lines = text.splitlines(keepends=True)
    return "".join(lines[:node.lineno - 1]) + replacement.rstrip() + "\n" + "".join(lines[node.end_lineno:])


def attach(text):
    text = replace_once(text, "import json\n", "import json\nimport importlib.util\n")
    fragment = '''
_SPEC = importlib.util.spec_from_file_location(
    "trnm_evidence_admission_" + Path(__file__).stem.replace("-", "_"),
    Path(__file__).with_name("evidence_admission.py"),
)
if _SPEC is None or _SPEC.loader is None:
    raise RuntimeError("cannot load shared evidence admission contract")
EVIDENCE = importlib.util.module_from_spec(_SPEC)
sys.modules[_SPEC.name] = EVIDENCE
_SPEC.loader.exec_module(EVIDENCE)
'''
    return replace_once(text, "ROOT = Path(__file__).resolve().parents[1]\n", "ROOT = Path(__file__).resolve().parents[1]\n" + fragment)


def load_replacement(name, error_name, arg, path_expression):
    return f'''def {name}({arg}) -> dict[str, Any]:
    try:
        return EVIDENCE.load_object({path_expression})
    except (OSError, ValueError, RecursionError) as error:
        raise {error_name}(f"invalid control JSON: {{error}}") from error
'''


def main():
    root = Path.cwd()
    with gzip.open(sys.argv[1], "rt", encoding="utf-8") as stream:
        raw = stream.read(1024 * 1024 + 1)
    require(len(raw) <= 1024 * 1024, "tooling payload exceeds budget")
    payload = json.loads(raw)
    require(subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() == SOURCE, "source HEAD changed")
    require(subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], text=True).strip() == TREE, "source tree changed")
    require(payload["source"] == SOURCE and payload["tree"] == TREE, "payload identity mismatch")
    originals = {name: (root / name).read_bytes() for name in EXPECTED}
    for name, data in originals.items():
        require(blob(data) == EXPECTED[name], "original source blob mismatch: " + name)
    # Reproduce the exact old manifest exception before changing source.
    spec = importlib.util.spec_from_file_location("baseline_gap_derivation", root / "scripts/derive-gap-status.py")
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    hostile = {"evidence_id": "TG-EV-FIXTURE-BYPASS", "status": "accepted", "evidence_type": "manifest",
               "compatibility_credit": False, "review": {"decision": "accepted"}}
    require(old.accepted_evidence(hostile) is True, "baseline bypass reproduction no longer applies")
    print("BASELINE_REPRODUCED: bare accepted manifest was eligible without independent identity or artifacts", flush=True)
    changed = {}
    for name, descriptor in payload["new_files"].items():
        require(name in {"scripts/evidence_admission.py", "tests/control_plane/test_evidence_admission.py"}, "unapproved new path")
        require(not (root / name).exists(), "new file already exists")
        data = descriptor["content"].encode()
        require(hashlib.sha256(data).hexdigest() == descriptor["sha256"], "new source digest mismatch")
        changed[name] = data.decode()
    s = attach(originals["scripts/check-evidence-index.py"].decode())
    s = replace_function(s, "load_object", load_replacement("load_object", "ValidationError", "path: Path", "path"))
    s = replace_function(s, "rows", '''def rows(index: dict[str, Any]) -> list[dict[str, Any]]:
    try:
        return EVIDENCE.index_rows(index)
    except EVIDENCE.AdmissionError as error:
        raise ValidationError(str(error)) from error
''')
    s = replace_function(s, "first", '''def first(row: dict[str, Any], *paths: str) -> Any:
    try:
        return EVIDENCE.exact_alias(row, *paths)
    except (ValueError, TypeError) as error:
        raise ValidationError(str(error)) from error
''')
    s = replace_function(s, "accepted_review", '''def accepted_review(
    row: dict[str, Any], *, target_commit: str | None = None,
    target_tree: str | None = None,
) -> dict[str, Any] | None:
    return EVIDENCE.accepted_review(row, target_commit=target_commit, target_tree=target_tree)
''')
    s = replace_once(s, '        if key in policy:\n            require(policy[key] is expected, f"evidence policy {key} must be {expected}")',
                     '        require(policy.get(key) is expected, f"evidence policy {key} must be {expected}")')
    s = replace_once(s, '            candidate_path = root / path_value\n', '''            try:
                candidate_path = EVIDENCE.repository_path(root, path_value)
            except (OSError, ValueError) as error:
                raise ValidationError(f"{evidence_id}: {error}") from error
''')
    s = replace_once(s, '        if credit_enabled(row):\n            credited += 1', '''        if status == "accepted" or credit_enabled(row):
            try:
                EVIDENCE.validate_entry(row, root=root, now=current_time)
            except (OSError, ValueError, TypeError, KeyError, RecursionError) as error:
                raise ValidationError(f"{evidence_id}: {error}") from error
        if credit_enabled(row):
            credited += 1''')
    s = replace_once(s, 'accepted_status_rows >= credited,', 'accepted_status_rows == credited,')
    changed["scripts/check-evidence-index.py"] = s

    s = attach(originals["scripts/derive-gap-status.py"].decode())
    s = replace_function(s, "load", load_replacement("load", "GapDerivationError", "path: Path", "path"))
    s = replace_function(s, "evidence_by_id", '''def evidence_by_id(index: dict[str, Any]) -> dict[str, dict[str, Any]]:
    try:
        return {row["evidence_id"]: row for row in EVIDENCE.index_rows(index)}
    except EVIDENCE.AdmissionError as error:
        raise GapDerivationError(str(error)) from error
''')
    s = replace_function(s, "accepted_evidence", '''def accepted_evidence(entry: dict[str, Any]) -> bool:
    return EVIDENCE.entry_eligible(entry, root=ROOT)
''')
    s = replace_once(s, '        if declared == "closed":\n            require(evidence_ids,', '''        if declared == "closed":
            try:
                EVIDENCE.validate_gap_evidence(gap, evidence, root=ROOT)
            except (OSError, ValueError, TypeError, KeyError, RecursionError) as error:
                raise GapDerivationError(f"{gap_id}: {error}") from error
            require(evidence_ids,''')
    changed["scripts/derive-gap-status.py"] = s

    s = attach(originals["scripts/derive-gates.py"].decode())
    s = replace_function(s, "load_json", load_replacement("load_json", "DerivationError", "path: str", "ROOT / path"))
    s = replace_function(s, "accepted_evidence", '''def accepted_evidence(entries: list[dict[str, Any]], now: datetime) -> list[dict[str, Any]]:
    accepted = []
    try:
        for row in EVIDENCE.index_rows({"entries": entries}):
            credit = EVIDENCE.exact_alias(row, "compatibility_credit", "claim_credit", "validity.compatibility_credit", "validity.claim_credit")
            if row.get("status") == "accepted" or credit is True:
                EVIDENCE.validate_entry(row, root=ROOT, now=now)
                accepted.append(row)
        if len({EVIDENCE.target_identity(row) for row in accepted}) > 1:
            fail("accepted gate evidence mixes candidate identities")
    except (OSError, ValueError, TypeError, KeyError, RecursionError) as error:
        raise DerivationError(str(error)) from error
    return accepted
''')
    s = replace_once(s, '    accepted = accepted_evidence(evidence_document.get("entries", []), now)', '''    try:
        entries = EVIDENCE.index_rows(evidence_document)
        evidence = {entry["evidence_id"]: entry for entry in entries}
        for gap in gaps.values():
            if gap.get("status") == "closed":
                EVIDENCE.validate_gap_evidence(gap, evidence, root=ROOT, now=now)
    except (OSError, ValueError, TypeError, KeyError, RecursionError) as error:
        raise DerivationError(str(error)) from error
    accepted = accepted_evidence(entries, now)''')
    s = replace_once(s, '        required_types = set(row.get("evidence_types", []))', '''        required_types = set(row.get("evidence_types", []))
        if not required_types or not required_types <= EVIDENCE.EVIDENCE_TYPES:
            fail(f"{gate_id}: nonempty supported evidence types required")''')
    changed["scripts/derive-gates.py"] = s

    s = attach(originals["scripts/check-gap-register.py"].decode())
    s = replace_function(s, "load_object", load_replacement("load_object", "ValidationError", "path: Path", "path"))
    s = replace_function(s, "indexed_evidence_rows", '''def indexed_evidence_rows(index: dict[str, Any]) -> dict[str, dict[str, Any]]:
    try:
        return {row["evidence_id"]: row for row in EVIDENCE.index_rows(index)}
    except EVIDENCE.AdmissionError as error:
        raise ValidationError(str(error)) from error
''')
    s = replace_function(s, "accepted_review", '''def accepted_review(row: dict[str, Any]) -> dict[str, Any] | None:
    try:
        _, commit, tree = EVIDENCE.target_identity(row)
    except (ValueError, TypeError):
        return None
    return EVIDENCE.accepted_review(row, target_commit=commit, target_tree=tree)
''')
    s = replace_once(s, '    require(evidence_ids, f"{gap_id}: closed gap requires indexed evidence")', '''    try:
        EVIDENCE.validate_gap_evidence({
            "id": gap_id, "evidence_ids": evidence_ids,
            "required_evidence_types": required_types, "external_dependency": None,
        }, evidence, root=ROOT)
    except (OSError, ValueError, TypeError, KeyError, RecursionError) as error:
        raise ValidationError(f"{gap_id}: {error}") from error
    require(evidence_ids, f"{gap_id}: closed gap requires indexed evidence")''')
    changed["scripts/check-gap-register.py"] = s

    s = attach(originals["scripts/check-status-transitions.py"].decode())
    s = replace_function(s, "load_json", load_replacement("load_json", "ValidationError", "path: str", "ROOT / path"))
    s = replace_function(s, "evidence_is_accepted", '''def evidence_is_accepted(row: dict[str, Any]) -> bool:
    return EVIDENCE.entry_eligible(row, root=ROOT)
''')
    s = replace_once(s, '    entries = unique_rows(index.get("entries", []), "evidence_id", "evidence entries")', '''    try:
        entries = {row["evidence_id"]: row for row in EVIDENCE.index_rows(index)}
    except EVIDENCE.AdmissionError as error:
        raise ValidationError(str(error)) from error''')
    s = replace_once(s, '        if row.get("compatibility_credit") is True:\n            require(evidence_id in accepted,', '''        if row.get("status") == "accepted" or row.get("compatibility_credit") is True:
            require(evidence_id in accepted,''')
    s = replace_once(s, '        if row.get("status") == "closed":\n            require(bool(evidence_ids),', '''        if row.get("status") == "closed":
            try:
                EVIDENCE.validate_gap_evidence(row, evidence, root=ROOT)
            except (OSError, ValueError, TypeError, KeyError, RecursionError) as error:
                raise ValidationError(f"{gap_id}: {error}") from error
            require(bool(evidence_ids),''')
    changed["scripts/check-status-transitions.py"] = s

    topic = originals["docs/TESTING_AND_EVIDENCE.md"].decode()
    topic = replace_once(topic, 'Revision: 2026-09-01', 'Revision: 2026-09-05')
    topic += payload["topic_append"]
    changed["docs/TESTING_AND_EVIDENCE.md"] = topic
    registry = json.loads(originals["docs/DOCUMENTATION_AUTHORITY.json"])
    registry["document_revisions"]["docs/TESTING_AND_EVIDENCE.md"] = "2026-09-05"
    changed["docs/DOCUMENTATION_AUTHORITY.json"] = json.dumps(registry, indent=2) + "\n"
    state = json.loads(originals["docs/status/CURRENT_STATE.json"])
    state["evidence"]["shared_retained_admission_source_candidate"] = {
        "implementation": "scripts/evidence_admission.py", "test": "tests/control_plane/test_evidence_admission.py",
        "accepted": False, "native_execution_required": True,
        "scope": "Shared structural admission and retained-byte checks; not independent or administrative acceptance.",
    }
    changed["docs/status/CURRENT_STATE.json"] = json.dumps(state, indent=2) + "\n"
    index = json.loads(originals["docs/evidence/index.json"])
    for requirement in index["pending_requirements"]:
        if requirement["id"] == "REQ-EV-CURRENT-HEAD-MERGE-GATE":
            requirement["description"] = "Bind the live PR #63 source head/tree and actual prospective merge through current GitHub metadata; older immutable observations below are historical, not current qualification. Retained bytes, shared admission validation, fresh independent acceptance, ordinary protected admission and post-merge main evidence remain required."
    index["generated_at"] = "2026-09-05"
    changed["docs/evidence/index.json"] = json.dumps(index, separators=(",", ":")) + "\n"
    gaps = json.loads(originals["docs/status/GAP_REGISTER.json"])
    for gap in gaps["gaps"]:
        if gap["id"] in {"GAP-P0-EVIDENCE-001", "GAP-P0-PLAN-001", "GAP-P1-REVIEW-001"}:
            gap["admission_source_candidate"] = {
                "source": "scripts/evidence_admission.py", "regression_suite": "tests/control_plane/test_evidence_admission.py",
                "scope": "One structural eligibility contract across index, gap, gate and execution-state consumers; mandatory review binding, schema and retained bytes.",
                "accepted": False, "gap_closed": False,
            }
    changed["docs/status/GAP_REGISTER.json"] = json.dumps(gaps, separators=(",", ":")) + "\n"
    roadmap = json.loads(originals["docs/roadmap/NEXT_MILESTONE.json"])
    roadmap["updated_at"] = "2026-09-05"
    for item in roadmap["items"]:
        if item["id"] == "TG-V3-002":
            item["admission_source_candidate"] = {"source": "scripts/evidence_admission.py", "independent_acceptance": False}
    changed["docs/roadmap/NEXT_MILESTONE.json"] = json.dumps(roadmap, separators=(",", ":")) + "\n"
    inventory = json.loads(originals["docs/status/IMPLEMENTATION_INVENTORY.json"])
    for component in inventory["components"]:
        if component["id"] == "COMP-CI-CONTROL":
            component["status"] = "shared-evidence-admission-source-candidate"
            component["implemented"].append("shared retained-evidence structural admission in five control consumers")
            component["missing"] = ["exact final-head and prospective-merge requalification", "independent retained-evidence acceptance", "required check enforcement", "ruleset read-back"]
            component["blocking_gaps"] = sorted(set(component["blocking_gaps"]) | {"GAP-P0-EVIDENCE-001", "GAP-P0-PLAN-001", "GAP-P1-REVIEW-001"})
    changed["docs/status/IMPLEMENTATION_INVENTORY.json"] = json.dumps(inventory, indent=2) + "\n"
    require(set(changed) == set(EXPECTED) | set(payload["new_files"]), "output set drift")
    for name, text in changed.items():
        (root / name).parent.mkdir(parents=True, exist_ok=True)
        (root / name).write_text(text, encoding="utf-8")
    tests = [
        ["python3", "-m", "compileall", "-q", "scripts", "tools", "tests"],
        ["python3", "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py", "-v"],
        ["python3", "scripts/check-documentation-authority.py"],
        ["python3", "scripts/check-plan.py"],
        ["python3", "scripts/check-evidence-index.py"],
        ["python3", "scripts/check-gap-register.py"],
        ["python3", "scripts/derive-gap-status.py"],
        ["python3", "scripts/derive-gates.py"],
        ["python3", "scripts/check-status-transitions.py"],
    ]
    outcomes = []
    for command in tests:
        result = subprocess.run(command, capture_output=True, text=True, timeout=180,
                                env={k: v for k, v in os.environ.items() if k not in {"GITHUB_TOKEN", "GH_TOKEN"}})
        text = result.stdout + result.stderr
        print("CHECK:", " ".join(command), "exit=", result.returncode, flush=True)
        if result.returncode:
            print("\n".join(text.splitlines()[-100:]), flush=True)
            raise RuntimeError("source preflight failed; no remote blobs published")
        count = re.search(r"Ran (\d+) tests", text)
        if count:
            print("tests=" + count.group(1), flush=True)
        outcomes.append({"command": command, "exit_code": result.returncode,
                         "output_sha256": hashlib.sha256(text.encode()).hexdigest(),
                         "tests": int(count.group(1)) if count else None})
    # Capability is used only for Git blob objects after all tests. Never mutate
    # refs, reviews, settings or claims; publication uses the connected Git API.
    token = os.environ["GITHUB_TOKEN"]
    entries = []
    for name, text in sorted(changed.items()):
        data = text.encode()
        expected = blob(data)
        request = urllib.request.Request(
            f"https://api.github.com/repos/{REPO}/git/blobs",
            data=json.dumps({"content": base64.b64encode(data).decode(), "encoding": "base64"}).encode(),
            headers={"Authorization": "Bearer " + token, "Accept": "application/vnd.github+json", "Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            saved = json.load(response)
        require(saved.get("sha") == expected, "remote blob mismatch: " + name)
        mode = "100644"
        if name in EXPECTED:
            mode = subprocess.check_output(["git", "ls-tree", SOURCE, "--", name], text=True).split()[0]
        entries.append({"path": name, "mode": mode, "type": "blob", "sha": expected})
    print("MATERIALIZATION_RECEIPT=" + json.dumps({"source": SOURCE, "tree": TREE, "entries": entries,
          "checks": outcomes, "candidate_acceptance": False, "ref_mutated": False, "review_submitted": False}, separators=(",", ":")), flush=True)


if __name__ == "__main__":
    main()
