#!/usr/bin/env python3
"""Fixed-source diagnostic preflight; publish blobs only, never refs or reviews."""
import base64, gzip, hashlib, json, os, re, subprocess, sys, tomllib, urllib.request
from pathlib import Path
BASE='b2fc8ea5ffeda4a5be2c783986b71b2892d162b6'
TREE='11b31a99f538049b06a1079848841a0f34c2693c'
REPO='TrillionniumFoundation/TrillionniumGame'
checks=[]

def git(*args):
    return subprocess.check_output(['git',*args],text=True,timeout=30).strip()
def blob(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def replace_once(path,old,new):
    value=path.read_text()
    if value.count(old)!=1: raise RuntimeError('anchor not unique: '+str(path)+repr(old[:60]))
    path.write_text(value.replace(old,new,1))
def run(command,timeout=180,env=None):
    environment=dict(os.environ if env is None else env)
    environment.pop('GITHUB_TOKEN',None)
    result=subprocess.run(command,env=environment,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
    output=result.stdout
    checks.append({'command':command,'exit_code':result.returncode,'sha256':hashlib.sha256(output).hexdigest()})
    print('CHECK',command,'EXIT',result.returncode,flush=True)
    print(output.decode('utf-8',errors='replace')[-14000:],flush=True)
    if result.returncode: raise RuntimeError('preflight failed')
    return output

def shell_block(path,job,label):
    text=path.read_text().split('  '+job+':\n',1)[1]
    text=re.split(r'\n  [a-z][a-z0-9-]*:\n',text,maxsplit=1)[0]
    step=text.split('      - name: '+label+'\n',1)[1].split('      - name:',1)[0]
    body=step.split('        run: |\n',1)[1]
    lines=[]
    for line in body.splitlines():
        if line.startswith('          '): lines.append(line[10:])
        elif not line.strip(): lines.append('')
        else: break
    if not lines or 'set -euo pipefail' not in lines: raise RuntimeError('unsupported live step')
    return '\n'.join(lines)+'\n'

def main():
    assert git('rev-parse','HEAD')==BASE and git('rev-parse','HEAD^{tree}')==TREE
    payload=json.loads(gzip.decompress(Path(sys.argv[1]).read_bytes()))
    assert payload['base']==BASE and payload['tree']==TREE
    old_probe=Path('crates/trnm-persistence-pg/src/bin/trnm-pg-tls-rotation-probe.rs').read_text()
    assert 'Err(_) => Ok(())' in old_probe
    print('BASELINE: reproduced source acceptance of arbitrary negative probe errors',flush=True)
    for path,edit in payload['edits'].items():
        p=Path(path); assert blob(p.read_bytes())==edit['sha'],path
        for pair in edit['replacements']: replace_once(p,pair['old'],pair['new'])
    for path,text in payload['new_files'].items():
        p=Path(path); assert not p.exists(),path
        p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
    lock=Path('Cargo.lock');text=lock.read_text()
    head='[[package]]\nname = "trnm-persistence-pg"\n'
    prefix,tail=text.split(head,1)
    section,suffix=tail.split('[[package]]',1)
    assert section.count(' "native-tls",\n')==1
    section=section.replace(' "native-tls",\n',' "native-tls",\n "openssl",\n')
    lock.write_text(prefix+head+section+'[[package]]'+suffix)
    tls=Path('.github/workflows/pg-tls-rotation.yml')
    replace_once(tls,"      - 'Cargo.lock'", "      - 'crates/trnm-persistence-pg/src/bin/tls_probe_witness/**'\n      - 'crates/trnm-persistence-pg/src/pool_parts/**'\n      - 'Cargo.lock'")
    replace_once(tls,"          grep -qx 'assertion=invalid_root_rejected' run/pg-tls/probe.env", """          grep -qx 'assertion=invalid_root_rejected' run/pg-tls/probe.env
          grep -qx 'assertion=all_negative_cases_have_fresh_healthy_controls' run/pg-tls/probe.env
          grep -qx 'assertion=unrelated_failures_do_not_count_as_certificate_rejection' run/pg-tls/probe.env
          grep -qx 'negative_attribution=bounded_openssl_x509_witness_and_native_pool_refusal' run/pg-tls/probe.env
          grep -qx 'invalid_root_scope=local_certificate_parse_rejection' run/pg-tls/probe.env""")
    crdb=Path('.github/workflows/cockroach-serialization-retry.yml')
    replace_once(crdb,"      - 'Cargo.lock'", "      - 'crates/trnm-persistence-pg/src/bin/trnm_server/retry_atomicity.rs'\n      - 'crates/trnm-persistence-pg/src/bin/trnm_server/pool.rs'\n      - 'crates/trnm-persistence-pg/src/pool_parts/**'\n      - 'migrations/cockroachdb/**'\n      - 'Cargo.lock'")
    proof_lines=[line.split('println!("',1)[1].split('");',1)[0]
        for line in Path('crates/trnm-persistence-pg/src/bin/trnm_server/retry_atomicity.rs').read_text().splitlines()
        if 'println!("assertion=' in line or 'println!("fault_mode=' in line or 'println!("network_response_loss_' in line]
    assert len(proof_lines)==9
    replace_once(crdb,"            run-cockroach-retry.log\n      - name: Seal", "            run-cockroach-retry.log\n"+''.join("          grep -qx '"+line+"' run-cockroach-retry.log\n" for line in proof_lines)+"      - name: Seal")
    replace_once(crdb,"            'multi_node_evidence=false'", "            'natural_write_skew_scope=classifier_and_supervisor_only' \\\n            'production_atomicity_scope=real_repository_with_commit_boundary_fault' \\\n            'multi_node_evidence=false'")
    overlay_path=Path('docs/governance/REQUIRED_WORKFLOWS_OVERLAY_V1.json')
    overlay=json.loads(overlay_path.read_text())
    for row in overlay['add_workflows']:
        if row['path'] in [str(tls),str(crdb)]:
            assert row['minimum_successful_execution_jobs']==2
            row['git_blob_sha1']=blob(Path(row['path']).read_bytes())
    assert overlay['composed_external_workflow_count']==55
    overlay.pop('overlay_sha256')
    overlay['overlay_sha256']=hashlib.sha256(json.dumps(overlay,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    overlay_path.write_text(json.dumps(overlay,sort_keys=True,separators=(',',':'))+'\n')
    documentation='''

## Database negative attribution and production retry proof

The TLS rotation binary now distinguishes a bounded, credential-free OpenSSL
X509 verification witness from native-tls pool admission. Only issuer/chain
verification codes qualify for a cross-root failure. Expiry, hostname, protocol,
connection, deadline, authentication and SQL failures cannot substitute. Each
negative is bracketed by fresh witness and authenticated pool/SQL controls on the
same single numeric loopback endpoint. The pool must also refuse the rejected
root. A malformed PEM is a local parser rejection, not remote TLS evidence.
The independent witness does not expose or change the production TLS connector.
Its TCP/SSLRequest/TLS I/O shares one two-second deadline; PEM reads are capped.
The existing pool's stalled-operation limitations still apply separately.
OpenSSL 0.10.81 was already locked transitively through native-tls; its direct
use is confined to this diagnostic binary. No dependency version is upgraded.

The Cockroach retry test retains the natural write-skew classifier/supervisor
phase, and additionally executes the real RetryingRepository -> PooledRepository
-> PgRepository transaction path against the authoritative migration. A dedicated
one-connection test pool enables Cockroach's session commit-error injection for
the first attempt, then disables it before retrying. Before retry it asserts zero
receipt/event/outbox/link rows and an unchanged entity head. Successful retry must
produce exactly one of each and preserve the complete command identity. A fresh
pool must replay the real durable receipt, while a changed fingerprint fails.
Repeated commit faults must exhaust the retry budget without partial effects.
The injection is test-only, confined to a newly created disposable loopback
database, and does not introduce a production fault hook or manufactured receipt.
This is commit-boundary fault evidence, not natural contention within the entire
production transaction, actual network response-loss injection, multi-node HA,
PITR, endurance, independent acceptance or complete Nakama compatibility.

Focused checks:

```bash
cargo test -p trnm-persistence-pg --locked --bin trnm-pg-tls-rotation-probe
cargo test -p trnm-persistence-pg --locked --bin trnm-server live_cockroach_serialization_failure_retries_entire_command -- --nocapture
```

The second command requires the isolated live database environment and explicit
required flag in its workflow to earn execution credit. Both workflows retain
source/unit and live jobs, nonempty-result assertions and exact definition pins.
'''
    readme=Path('crates/trnm-persistence-pg/README.md');readme.write_text(readme.read_text()+documentation)
    topic=Path('docs/TESTING_AND_EVIDENCE.md');topic.write_text(topic.read_text()+documentation.replace('## Database negative attribution and production retry proof','## 14. Database negative attribution and production retry proof'))
    for path,key,target in [('docs/status/GAP_REGISTER.json','gaps','GAP-P1-PG-001'),('docs/roadmap/NEXT_MILESTONE.json','items','TG-V3-009')]:
        p=Path(path);doc=json.loads(p.read_text())
        row=next(r for r in doc[key] if r['id']==target)
        row['database_qualification_source_candidate']={'tls':'bounded typed X509 witness plus same-endpoint healthy pool controls','retry':'real pooled commit with server-side commit-boundary injection and durable replay','accepted':False,'gap_closed':False}
        p.write_text(json.dumps(doc,separators=(',',':'))+'\n')
    run(['cargo','fmt','--all'])
    run(['cargo','test','-p','trnm-persistence-pg','--all-targets','--locked'],600)
    run(['cargo','clippy','-p','trnm-persistence-pg','--all-targets','--locked','--','-D','warnings'],300)
    run(['python3','-m','unittest','discover','-s','tests','-p','test_*.py','-v'])
    run(['python3','scripts/check-documentation-authority.py'])
    run(['python3','scripts/check-plan.py'])
    env=dict(os.environ)
    env.update(CANDIDATE_SHA=BASE, GITHUB_REPOSITORY=REPO, RUST_TOOLCHAIN='1.85.1',
        COCKROACH_IMAGE='cockroachdb/cockroach@sha256:c0838fd4db940b7dedb590211ee3cd229b75d3b49ce466760454a282b98641ae',
        PGPASSWORD='tls_rotation_test_password',
        TRNM_TLS_ROTATION_OLD_DATABASE_URL='postgresql://postgres:tls_rotation_test_password@127.0.0.1:55432/trillionnium_tls',
        TRNM_TLS_ROTATION_NEW_DATABASE_URL='postgresql://postgres:tls_rotation_test_password@127.0.0.1:55433/trillionnium_tls',
        TRNM_TLS_ROTATION_OLD_ROOT_CERT_PEM='run/pg-tls/old/ca.crt',
        TRNM_TLS_ROTATION_NEW_ROOT_CERT_PEM='run/pg-tls/new/ca.crt',
        TRNM_TLS_ROTATION_OLD_GENERATION='41', TRNM_TLS_ROTATION_NEW_GENERATION='42',
        TRNM_REQUIRE_LIVE_CRDB_RETRY='1',
        TRNM_TEST_COCKROACH_URL='postgresql://root@127.0.0.1:26257/defaultdb?sslmode=disable')
    env['POSTGRES_IMAGE']=re.search(r'^  POSTGRES_IMAGE: (.+)$',tls.read_text(),re.M).group(1)
    assert '@sha256:' in env['POSTGRES_IMAGE']
    try:
        for name in ['Generate independent old and new certificate authorities','Start two exact PostgreSQL TLS endpoints','Prove monotonic rolling trust rotation and fail-closed roots']:
            run(['bash','-c',shell_block(tls,'live-postgresql-tls-rotation',name)],300,env)
        for name in ['Start exact CockroachDB single-node profile','Force SQLSTATE 40001 and prove whole-command retry']:
            run(['bash','-c',shell_block(crdb,'live-cockroach-serialization-retry',name)],300,env)
    finally:
        for name in ['trnm-pg-old','trnm-pg-new','trnm-crdb-retry']:
            subprocess.run(['docker','rm','-f',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=30)
    git('add','Cargo.lock','crates/trnm-persistence-pg','.github/workflows/pg-tls-rotation.yml','.github/workflows/cockroach-serialization-retry.yml','docs','tests/control_plane/test_database_qualification_paths.py')
    changed=git('diff','--cached','--name-only').splitlines()
    assert 8<=len(changed)<=16,changed
    token=os.environ['GITHUB_TOKEN']
    entries=[]
    for name in changed:
        data=Path(name).read_bytes();expected=blob(data)
        body=json.dumps({'encoding':'base64','content':base64.b64encode(data).decode()}).encode()
        req=urllib.request.Request('https://api.github.com/repos/'+REPO+'/git/blobs',data=body,method='POST',headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=30) as response: actual=json.load(response)['sha']
        assert actual==expected
        mode=git('ls-files','--stage',name).split()[0]
        entries.append({'path':name,'mode':mode,'type':'blob','sha':actual})
    print('MATERIALIZATION_RECEIPT='+json.dumps({'base':BASE,'base_tree':TREE,'entries':entries,'checks':checks,'accepted':False,'refs_modified':False,'review_submitted':False},separators=(',',':')),flush=True)
if __name__=='__main__':main()
